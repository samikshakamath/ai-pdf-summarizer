import json
import boto3
import PyPDF2
from urllib.parse import unquote_plus

# AWS clients
s3 = boto3.client("s3")

bedrock = boto3.client(
    service_name="bedrock-runtime",
    region_name="us-east-1"
)

MODEL_ID = "amazon.nova-lite-v1:0"


def lambda_handler(event, context):

    # Get uploaded file information
    bucket_name = event['Records'][0]['s3']['bucket']['name']

    file_key = unquote_plus(
        event['Records'][0]['s3']['object']['key']
    )

    print("Bucket:", bucket_name)
    print("File Key:", file_key)

    # Download PDF to temporary Lambda storage
    download_path = f"/tmp/{file_key}"

    s3.download_file(bucket_name, file_key, download_path)

    # Read PDF
    pdf_reader = PyPDF2.PdfReader(download_path)

    extracted_text = ""

    for page in pdf_reader.pages:
        text = page.extract_text()

        if text:
            extracted_text += text

    # Limit extracted text size
    extracted_text = extracted_text[:5000]

    print("===== EXTRACTED TEXT =====")
    print(extracted_text[:1000])
    print("===== END EXTRACTED TEXT =====")

    # Prompt for Nova Lite
    prompt = f"""
    Summarize this PDF in concise bullet points:

    {extracted_text}
    """

    # Request body for Nova Lite
    body = {
        "messages": [
            {
                "role": "user",
                "content": [
                    {
                        "text": prompt
                    }
                ]
            }
        ],
        "inferenceConfig": {
            "max_new_tokens": 300,
            "temperature": 0.5
        }
    }

    # Invoke Nova Lite model
    response = bedrock.invoke_model(
        modelId=MODEL_ID,
        body=json.dumps(body),
        contentType="application/json",
        accept="application/json"
    )

    response_body = json.loads(response["body"].read())

    summary = response_body["output"]["message"]["content"][0]["text"]

    print("===== GENERATED SUMMARY =====")
    print(summary)
    print("===== END SUMMARY =====")

    # Create summary filename
    summary_key = file_key.replace(".pdf", "_summary.txt")

    # Upload summary back to S3
    s3.put_object(
        Bucket=bucket_name,
        Key=summary_key,
        Body=summary.encode("utf-8"),
        ContentType="text/plain"
    )

    print(f"Summary uploaded to S3: {summary_key}")

    return {
        "statusCode": 200,
        "body": json.dumps({
            "message": "Summary generated successfully",
            "summary_file": summary_key
        })
    }